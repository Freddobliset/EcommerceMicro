﻿namespace Ecommerce.Kafka.Utility
{
    public class Class1
    {

    }
}
