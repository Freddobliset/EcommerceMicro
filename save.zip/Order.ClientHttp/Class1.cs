﻿namespace Order.ClientHttp
{
    public class Class1
    {

    }
}
